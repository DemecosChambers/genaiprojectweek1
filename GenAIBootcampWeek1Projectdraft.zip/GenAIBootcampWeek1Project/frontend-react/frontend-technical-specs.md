# Frontend Server Technical Specs
## Pages

### Dashboard /dashboard
 
This page contains the following components
Last Study Session
Study Progress
Quick Stats
Start Studying Button


We'll need the following API Endpoints

GET /dashboard/last_study_session
GET /dashboard/study_progress
GET /dashboard/quick-stats