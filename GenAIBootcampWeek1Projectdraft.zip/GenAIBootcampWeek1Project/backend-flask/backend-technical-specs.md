# Backend Server Technical Specs

## Business Goal:

A language learning school wants to build a prototype of learning portal which will act as three things:
Inventory of possible vocabulary that can be learned
Act as a  Learning record store (LRS), providing correct and wrong score on practice vocabulary
A unified launchpad to launch different learning apps

You have been tasked with creating the backend API of the application.

## Technical Requirements 

- The backend will be built using Go
- The datasbase will be SQLite3
- The API will be build using Gin
- The API will always return JSON
- There will be no authentication or authorization
- everything will be treated as a single user

## Database Schema 

We have the following tables:

- words
    - ID - integer
    - Spanish - string
    - English - string
    - Slang - string
    - Parts - json infrastrucutreion - json
- words_groups - join table for words and groups
many-to-many
    -id - integer
    - word_id - integer
    - group_id - integer 
- groups - thematic groups of words
    - id - integer 
    - name - string
- study_sessions - records of study sessions grouping
word_review_items
    - id - integer
    - study_sessions_id - integer 
    - group_id - integer
    - created_at datetime
- study_activities - a specific study activity, linking a study session to group
    - id - integer 
    - study_session - integer 
    - group_id - integer 
- word_review_items - a record of word practice, determing if the word is correct or not
    - id - integer
    - word_id - integer 
    - study_sessions_id - integer 
    - correct - boolean 
    - created_at datetime

## API Endpoints
GET /words - Get paginated list of words with review statistics
GET /words/id - Get paginated list of words with review statistics
GET /groups - Get paginated list of word groups with word counts
GET /groups/:id - Get words from a specific group (This is intended to be used by target apps)
GET /groups/:id - Get words from a specific group (This is intended to be used by target apps)
POST /study_sessions - Create a new study session for a group
POST /study_sessions/:id/review - Log a review attempt for a word during a study session