## Setting up the database

```sh
invoke init-db
```

This will do the following:
- create the words.db (Sqlite3 database)
- run the migrations found in `seeds/`
- run the seed data found in `seed/`

Please note that migrations and seed data is manually coded to be imported in the `lib/db.py`. So you need to modify this code if you want to import other seed data.

## Clearing the database

Simply delete the `words.db` to clear entire database.

## Running the backend api

```sh
python app.py 
```

This should start the flask app on port `5000`

# Backend Server Technical Specs

## Business Goal:

A language learning school wants to build a prototype of learning portal which will act as three things:
Inventory of possible vocabulary that can be learned
Act as a  Learning record store (LRS), providing correct and wrong score on practice vocabulary
A unified launchpad to launch different learning apps

You have been tasked with creating the backend API of the application.

## Technical Requirements 

- The backend will be built using Go
- The datasbase will be SQLite3
- The API will be build using Gin
- The API will always return JSON
- There will be no authentication or authorization
- everything will be treated as a single user

## Database Schema 

We have the following tables:

- words
    - ID - integer
    - Spanish - string
    - English - string
    - Slang - string
    - Parts - json infrastrucutreion - json
- words_groups - join table for words and groups
many-to-many
    -id - integer
    - word_id - integer
    - group_id - integer 
- groups - thematic groups of words
    - id - integer 
    - name - string
- study_sessions - records of study sessions grouping
word_review_items
    - id - integer 
    - group_id - integer 
    - created_at datetime
    - study activity_id - integer
- study_activities - a specific study activity, linking a study session to group
    - id - integer 
    - study_session - integer 
    - group_id - integer 
    - created_at datetime
- word_review_items - a record of word practice, determing if the word is correct or not
    - word_id integer
    - study_sessions_id - integer 
    - correct - boolean
    - created_at datetime
   

## API Endpoints

- GET /api/dashboard/last_study_session
- GET /api/dashboard/study_progress
- GET /api/dashboard/quick-stats
- GET /api/study_activies/:id
- Get /api/study_activies/:id/study_sessions
- Post /api/study_activities
    - required params: group_id, study_activity_id
- GET /api/words 
    - pagination with 100 items per page
- GET /api/words/:id 
- GET /api/groups 
    - pagination with 100 items per page
- GET /api/groups/:id 
- GET /api/groups/:id/words 
- GET /api/groups/:id/words/study_sessions
- GET /api/study_sessions
    - pagination with 100 items per page
- GET /api/study_sessions/:id
- GET /api/study_sessions/:id/words
- POST /api/reset_history
- POST /api/full_reset
- POST /api/study_sessions/:id/words/:word_id/review
    - required params: correct